from django.shortcuts import render, HttpResponseRedirect
from .forms import SignUpForm, LoginForm, Userprofileform
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash




# Create your views here.
def home(request):
    return render(request, 'enroll/home.html')

def dashboard(request):
    if request.user.is_authenticated:
        return render(request, 'enroll/dashboard.html',{'name':request.user, 'pic':request.user.userprofile.image.url})
    else:
        return HttpResponseRedirect('/login/')

def user_logout(request):
    logout(request)
    return HttpResponseRedirect('/')

def signup(request):
    if request.method == "POST":
        form = SignUpForm(request.POST)
        profile_form = Userprofileform(request.POST, request.FILES)

        if form.is_valid() and profile_form.is_valid():
            user = form.save()
            profile = profile_form.save(commit=False)
            profile.user = user
            profile.save()
            messages.success(request, 'congratulation!! you have become an auther.')
           
    else:
        form = SignUpForm()
        profile_form = Userprofileform()

    return render(request, 'enroll/signup.html',{'form':form, 'profile_form':profile_form})

def user_login(request):
    if not request.user.is_authenticated:
        if request.method == "POST":
            form = LoginForm(request=request, data=request.POST)
            if form.is_valid():
                uname = form.cleaned_data['username']
                ppass = form.cleaned_data['password']
                users = authenticate(username=uname,password=ppass)
                if users is not None:
                    login(request, users)
                    messages.success(request, 'Logged in succesfully !!')
                    return HttpResponseRedirect('/dashboard/')
        else:
            form = LoginForm()
        return render(request, 'enroll/login.html',{'form':form})
    else:
        return HttpResponseRedirect('/dashboard/')


def changepassword(request):
        if request.method == "POST":
            form = PasswordChangeForm(user=request.user, data=request.POST)
            if form.is_valid():
                user = form.save()
                update_session_auth_hash(request, user)
                return HttpResponseRedirect('/dashboard/')
        else:
            form = PasswordChangeForm(request.user)
        return render(request, 'enroll/changepassword.html',{'form':form})

